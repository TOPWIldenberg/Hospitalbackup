<h1>Add species</h1>
<form action="<?= URL ?>species/addSave" method="post">
	<label>Species</label><input type="text" name="species">
	<input type="submit" value="Submit">
</form>