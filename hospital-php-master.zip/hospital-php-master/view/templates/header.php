<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Hospital</title>
	<link rel="stylesheet" href="<?= URL ?>css/style.css" type="text/css">
</head>
<body>
	<h1>Hospital</h1>
	<ul>
		<li><a href="<?= URL ?>patients/index">Patiënts</a></li>
		<li><a href="<?= URL ?>clients/index">Clients</a></li>
		<li><a href="<?= URL ?>species/index">Species</a></li>
	</ul>	